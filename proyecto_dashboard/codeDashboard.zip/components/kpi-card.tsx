"use client"

import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, TrendingDown, type LucideIcon } from 'lucide-react'
import { cn } from "@/lib/utils"

interface KPICardProps {
  title: string
  value: string
  unit?: string
  description?: string
  icon: LucideIcon
  trend?: {
    value: number
    direction: "up" | "down"
  }
  highlight?: "primary" | "secondary"
}

export function KPICard({ title, value, unit, description, icon: Icon, trend, highlight }: KPICardProps) {
  return (
    <Card className={cn(
      highlight === "primary" && "border-primary/30 bg-primary/5",
      highlight === "secondary" && "border-accent/30 bg-accent/5"
    )}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground mb-2">{title}</p>
            <div className="flex items-baseline gap-2">
              <h3 className="text-3xl font-bold text-foreground">{value}</h3>
              {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
            </div>
            {description && (
              <p className="text-xs text-muted-foreground mt-2">{description}</p>
            )}
            {trend && (
              <div className="flex items-center gap-1 mt-2">
                {trend.direction === "up" ? (
                  <TrendingUp className="w-4 h-4 text-chart-1" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-destructive" />
                )}
                <span className={cn(
                  "text-sm font-medium",
                  trend.direction === "up" ? "text-chart-1" : "text-destructive"
                )}>
                  {trend.value}% vs mes anterior
                </span>
              </div>
            )}
          </div>
          <div className={cn(
            "p-3 rounded-lg",
            highlight === "primary" ? "bg-primary/10" : 
            highlight === "secondary" ? "bg-accent/10" : 
            "bg-muted"
          )}>
            <Icon className={cn(
              "w-6 h-6",
              highlight === "primary" ? "text-primary" :
              highlight === "secondary" ? "text-accent" :
              "text-muted-foreground"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
