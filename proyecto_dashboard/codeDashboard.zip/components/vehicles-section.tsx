"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Truck, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react'

const vehicles = [
  {
    id: 1,
    nombre: "Camioneta Municipal 01",
    tipo: "Camioneta",
    patente: "AB 123 CD",
    combustible: "Nafta",
    consumoMensual: 2280,
    limiteAlerta: 2500,
    eficiencia: 92,
    trend: { value: 5.2, direction: "up" as const },
    estado: "activo" as const,
  },
  {
    id: 2,
    nombre: "Camioneta Municipal 02",
    tipo: "Camioneta",
    patente: "EF 456 GH",
    combustible: "Nafta",
    consumoMensual: 2150,
    limiteAlerta: 2500,
    eficiencia: 95,
    trend: { value: 2.1, direction: "down" as const },
    estado: "activo" as const,
  },
  {
    id: 3,
    nombre: "Camión Recolector 01",
    tipo: "Camión",
    patente: "IJ 789 KL",
    combustible: "Diesel",
    consumoMensual: 4280,
    limiteAlerta: 4000,
    eficiencia: 88,
    trend: { value: 12.3, direction: "up" as const },
    estado: "alerta" as const,
  },
  {
    id: 4,
    nombre: "Ambulancia 01",
    tipo: "Ambulancia",
    patente: "MN 012 OP",
    combustible: "Nafta",
    consumoMensual: 850,
    limiteAlerta: 1200,
    eficiencia: 98,
    trend: { value: 3.5, direction: "down" as const },
    estado: "activo" as const,
  },
  {
    id: 5,
    nombre: "Motoniveladora",
    tipo: "Maquinaria Pesada",
    patente: "QR 345 ST",
    combustible: "Diesel",
    consumoMensual: 2890,
    limiteAlerta: 3000,
    eficiencia: 90,
    trend: { value: 1.8, direction: "down" as const },
    estado: "activo" as const,
  },
]

interface VehiclesSectionProps {
  selectedYear: string
}

export function VehiclesSection({ selectedYear }: VehiclesSectionProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Gestión de Vehículos</h2>
        <p className="text-muted-foreground">
          Información detallada de consumo por vehículo
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {vehicles.map((vehicle) => (
          <Card key={vehicle.id} className={vehicle.estado === "alerta" ? "border-destructive/50" : ""}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{vehicle.nombre}</CardTitle>
                  <CardDescription className="mt-1">
                    {vehicle.tipo} • {vehicle.patente}
                  </CardDescription>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge variant={vehicle.combustible === "Diesel" ? "default" : "secondary"}>
                    {vehicle.combustible}
                  </Badge>
                  {vehicle.estado === "alerta" && (
                    <Badge variant="destructive" className="gap-1">
                      <AlertCircle className="w-3 h-3" />
                      Alerta
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Consumo mensual</span>
                  <span className="font-bold text-lg">{vehicle.consumoMensual.toLocaleString()} L</span>
                </div>
                <Progress 
                  value={(vehicle.consumoMensual / vehicle.limiteAlerta) * 100} 
                  className="h-2"
                />
                <div className="flex items-center justify-between text-xs text-muted-foreground mt-1">
                  <span>Límite de alerta: {vehicle.limiteAlerta} L</span>
                  <span>{((vehicle.consumoMensual / vehicle.limiteAlerta) * 100).toFixed(0)}%</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Eficiencia</p>
                  <p className="text-2xl font-bold text-foreground">{vehicle.eficiencia}%</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Tendencia</p>
                  <div className="flex items-center gap-1">
                    {vehicle.trend.direction === "up" ? (
                      <TrendingUp className="w-4 h-4 text-destructive" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-chart-1" />
                    )}
                    <span className={`text-sm font-semibold ${
                      vehicle.trend.direction === "up" ? "text-destructive" : "text-chart-1"
                    }`}>
                      {vehicle.trend.value}%
                    </span>
                  </div>
                </div>
              </div>

              <Button variant="outline" className="w-full" size="sm">
                Ver detalles completos
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
