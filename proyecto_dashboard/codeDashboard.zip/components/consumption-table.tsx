"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Eye } from 'lucide-react'
import { fuelData, monthNames } from "@/lib/fuel-data"

export function ConsumptionTable() {
  const tableData = fuelData.slice().reverse().slice(0, 6).map((month, index) => ({
    id: index + 1,
    mes: monthNames[month.Mes - 1],
    gasoil: month["Gasoil (L)"],
    nafta: month["Nafta (L)"],
    total: month["Gasoil (L)"] + month["Nafta (L)"],
    km: month["Km Recorridos"],
    eficiencia: (month["Km Recorridos"] / (month["Gasoil (L)"] + month["Nafta (L)"])).toFixed(2),
    viajesLargos: month["Viajes Largos"]
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Resumen Mensual de Consumo</CardTitle>
        <CardDescription>Últimos 6 meses de 2024</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mes</TableHead>
                <TableHead className="text-right">Gasoil (L)</TableHead>
                <TableHead className="text-right">Nafta (L)</TableHead>
                <TableHead className="text-right">Total (L)</TableHead>
                <TableHead className="text-right">Km</TableHead>
                <TableHead className="text-right">Eficiencia</TableHead>
                <TableHead className="text-center">Viajes Largos</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tableData.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.mes}</TableCell>
                  <TableCell className="text-right">{item.gasoil.toLocaleString('es-AR')}</TableCell>
                  <TableCell className="text-right">{item.nafta.toLocaleString('es-AR')}</TableCell>
                  <TableCell className="text-right font-semibold">{item.total.toLocaleString('es-AR')}</TableCell>
                  <TableCell className="text-right">{item.km.toLocaleString('es-AR')}</TableCell>
                  <TableCell className="text-right">
                    <Badge variant={parseFloat(item.eficiencia) > 5 ? "default" : "secondary"}>
                      {item.eficiencia} km/L
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline">{item.viajesLargos}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
