"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { fuelData, monthNames } from "@/lib/fuel-data"

export function ConsumptionChart() {
  const chartData = fuelData.map((month) => ({
    mes: monthNames[month.Mes - 1].slice(0, 3),
    gasoil: month["Gasoil (L)"],
    nafta: month["Nafta (L)"],
    total: month["Gasoil (L)"] + month["Nafta (L)"]
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Consumo Mensual por Tipo</CardTitle>
        <CardDescription>Distribución de Gasoil y Nafta durante 2024</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="mes" 
              className="text-xs"
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
            />
            <YAxis 
              className="text-xs"
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
              }}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="gasoil" 
              stroke="hsl(var(--chart-1))" 
              strokeWidth={2}
              name="Gasoil (litros)"
            />
            <Line 
              type="monotone" 
              dataKey="nafta" 
              stroke="hsl(var(--chart-2))" 
              strokeWidth={2}
              name="Nafta (litros)"
            />
            <Line 
              type="monotone" 
              dataKey="total" 
              stroke="hsl(var(--chart-3))" 
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Total (litros)"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
