"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const monthlyData = [
  { mes: "Ene 23", consumo: 11200, gasto: 2856000 },
  { mes: "Feb 23", consumo: 10800, gasto: 2754000 },
  { mes: "Mar 23", consumo: 11500, gasto: 2932500 },
  { mes: "Abr 23", consumo: 10900, gasto: 2779500 },
  { mes: "May 23", consumo: 11300, gasto: 2881500 },
  { mes: "Jun 23", consumo: 10700, gasto: 2728500 },
  { mes: "Jul 23", consumo: 11100, gasto: 2830500 },
  { mes: "Ago 23", consumo: 10600, gasto: 2703000 },
  { mes: "Sep 23", consumo: 11400, gasto: 2907000 },
  { mes: "Oct 23", consumo: 11000, gasto: 2805000 },
  { mes: "Nov 23", consumo: 11600, gasto: 2958000 },
  { mes: "Dic 23", consumo: 11200, gasto: 2856000 },
  { mes: "Ene 24", consumo: 12450, gasto: 3244875 },
]

const weeklyData = [
  { semana: "Sem 1", diesel: 2200, nafta: 850 },
  { semana: "Sem 2", diesel: 2350, nafta: 920 },
  { semana: "Sem 3", diesel: 2180, nafta: 880 },
  { semana: "Sem 4", diesel: 2220, nafta: 850 },
]

interface HistoricalSectionProps {
  selectedYear: string
  selectedVehicle: string
}

export function HistoricalSection({ selectedYear, selectedVehicle }: HistoricalSectionProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Análisis Histórico</h2>
        <p className="text-muted-foreground">
          Tendencias y evolución del consumo de combustible
        </p>
      </div>

      <Tabs defaultValue="mensual" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="mensual">Análisis Mensual</TabsTrigger>
          <TabsTrigger value="semanal">Análisis Semanal</TabsTrigger>
        </TabsList>

        <TabsContent value="mensual" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Evolución del Consumo</CardTitle>
              <CardDescription>Consumo total mensual en litros (2023-2024)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={monthlyData}>
                  <defs>
                    <linearGradient id="colorConsumo" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="mes" 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="consumo" 
                    stroke="hsl(var(--chart-1))" 
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorConsumo)"
                    name="Litros"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Evolución del Gasto</CardTitle>
              <CardDescription>Gasto total mensual en pesos argentinos</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="mes" 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => `$${value.toLocaleString()}`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="gasto" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={3}
                    name="Gasto (ARS)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="semanal" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Consumo Semanal por Tipo</CardTitle>
              <CardDescription>Distribución semanal de diesel y nafta - Enero 2024</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={weeklyData}>
                  <defs>
                    <linearGradient id="colorDiesel" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorNafta" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="semana" 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="diesel" 
                    stackId="1"
                    stroke="hsl(var(--chart-1))" 
                    fill="url(#colorDiesel)"
                    name="Diesel (L)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="nafta" 
                    stackId="1"
                    stroke="hsl(var(--chart-2))" 
                    fill="url(#colorNafta)"
                    name="Nafta (L)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
