"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { fuelData } from "@/lib/fuel-data"

export function VehicleComparisonChart() {
  const totals = fuelData.reduce((acc, month) => {
    acc.camionesTanque += month["Camiones Tanque"]
    acc.compactadores += month["Compactadores"]
    acc.camionetas += month["Camionetas"]
    acc.tractores += month["Tractores"]
    acc.retroexcavadoras += month["Retroexcavadoras"]
    acc.motos += month["Motos"]
    acc.motosNiveladoras += month["Motos Niveladoras"]
    return acc
  }, {
    camionesTanque: 0,
    compactadores: 0,
    camionetas: 0,
    tractores: 0,
    retroexcavadoras: 0,
    motos: 0,
    motosNiveladoras: 0
  })

  const data = [
    { vehiculo: "Camiones Tanque", cantidad: totals.camionesTanque },
    { vehiculo: "Compactadores", cantidad: totals.compactadores },
    { vehiculo: "Camionetas", cantidad: totals.camionetas },
    { vehiculo: "Tractores", cantidad: totals.tractores },
    { vehiculo: "Retroexcavadoras", cantidad: totals.retroexcavadoras },
    { vehiculo: "Motos", cantidad: totals.motos },
    { vehiculo: "Motos Niveladoras", cantidad: totals.motosNiveladoras },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Uso de Vehículos por Tipo</CardTitle>
        <CardDescription>Cantidad de usos registrados durante 2024</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="vehiculo" 
              className="text-xs"
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
              angle={-45}
              textAnchor="end"
              height={100}
            />
            <YAxis 
              className="text-xs"
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
              }}
            />
            <Bar dataKey="cantidad" fill="hsl(var(--chart-1))" radius={[8, 8, 0, 0]} name="Usos" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
