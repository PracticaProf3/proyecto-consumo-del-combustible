"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { KPICard } from "@/components/kpi-card"
import { ConsumptionChart } from "@/components/consumption-chart"
import { VehicleComparisonChart } from "@/components/vehicle-comparison-chart"
import { FuelTypeChart } from "@/components/fuel-type-chart"
import { ConsumptionTable } from "@/components/consumption-table"
import { TrendingUp, TrendingDown, Fuel, DollarSign, Car, Activity } from 'lucide-react'
import { 
  getTotalConsumption, 
  getAverageEfficiency, 
  getMonthWithMaxConsumption,
  getMonthWithMinConsumption,
  getTotalGasoil,
  getTotalNafta
} from "@/lib/fuel-data"

interface OverviewSectionProps {
  selectedYear: string
  selectedVehicle: string
}

export function OverviewSection({ selectedYear, selectedVehicle }: OverviewSectionProps) {
  const totalConsumption = getTotalConsumption()
  const totalGasoil = getTotalGasoil()
  const totalNafta = getTotalNafta()
  const averageEfficiency = getAverageEfficiency()
  const maxMonth = getMonthWithMaxConsumption()
  const minMonth = getMonthWithMinConsumption()
  
  // Precio estimado del combustible (ARS por litro)
  const precioGasoil = 800
  const precioNafta = 900
  const gastoTotal = (totalGasoil * precioGasoil) + (totalNafta * precioNafta)

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <KPICard
          title="Consumo Total Anual"
          value={totalConsumption.toLocaleString('es-AR')}
          unit="litros"
          description="Año 2024"
          icon={Fuel}
          trend={{ value: 8.2, direction: "up" }}
        />
        <KPICard
          title="Gasto Total Estimado"
          value={`$${(gastoTotal / 1000000).toFixed(2)}M`}
          unit="ARS"
          description="Año 2024"
          icon={DollarSign}
          trend={{ value: 12.5, direction: "up" }}
        />
        <KPICard
          title="Eficiencia Promedio"
          value={averageEfficiency}
          unit="km/litro"
          description="Todos los vehículos"
          icon={Activity}
        />
        <KPICard
          title="Mayor Consumo Mensual"
          value={maxMonth.month}
          unit={`${maxMonth.consumption.toLocaleString('es-AR')} litros`}
          description="Mes con mayor consumo"
          icon={Car}
          highlight="primary"
        />
        <KPICard
          title="Menor Consumo Mensual"
          value={minMonth.month}
          unit={`${minMonth.consumption.toLocaleString('es-AR')} litros`}
          description="Mes con menor consumo"
          icon={Car}
          highlight="secondary"
        />
        <KPICard
          title="Distribución Combustible"
          value={`${((totalGasoil / totalConsumption) * 100).toFixed(1)}%`}
          unit="Gasoil"
          description={`${((totalNafta / totalConsumption) * 100).toFixed(1)}% Nafta`}
          icon={TrendingUp}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <ConsumptionChart />
        <VehicleComparisonChart />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ConsumptionTable />
        </div>
        <FuelTypeChart />
      </div>
    </div>
  )
}
