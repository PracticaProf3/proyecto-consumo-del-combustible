"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Download, FileText, FileSpreadsheet, Calendar } from 'lucide-react'

interface ReportsSectionProps {
  selectedYear: string
  selectedVehicle: string
}

const reportTypes = [
  {
    id: "consumo-mensual",
    titulo: "Reporte Mensual de Consumo",
    descripcion: "Análisis detallado del consumo mensual por vehículo",
    formatos: ["PDF", "Excel"],
    frecuencia: "Mensual",
  },
  {
    id: "gastos-anuales",
    titulo: "Gastos Anuales Consolidados",
    descripcion: "Resumen de gastos totales por año fiscal",
    formatos: ["PDF", "Excel"],
    frecuencia: "Anual",
  },
  {
    id: "comparativa-vehiculos",
    titulo: "Comparativa de Vehículos",
    descripcion: "Análisis comparativo de eficiencia entre vehículos",
    formatos: ["PDF", "Excel"],
    frecuencia: "Trimestral",
  },
  {
    id: "alertas-historial",
    titulo: "Historial de Alertas",
    descripcion: "Registro completo de alertas y eventos",
    formatos: ["PDF", "CSV"],
    frecuencia: "Mensual",
  },
  {
    id: "auditoria-cargas",
    titulo: "Auditoría de Cargas",
    descripcion: "Detalle de todas las cargas realizadas con timestamps",
    formatos: ["Excel", "CSV"],
    frecuencia: "Mensual",
  },
  {
    id: "tendencias-anuales",
    titulo: "Tendencias y Proyecciones",
    descripcion: "Análisis de tendencias con proyecciones futuras",
    formatos: ["PDF"],
    frecuencia: "Trimestral",
  },
]

export function ReportsSection({ selectedYear, selectedVehicle }: ReportsSectionProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Centro de Reportes</h2>
        <p className="text-muted-foreground">
          Genera y descarga reportes personalizados
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configuración de Reporte</CardTitle>
          <CardDescription>Los reportes se generarán según los filtros seleccionados en el header</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Período Seleccionado</p>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span className="font-semibold">{selectedYear === "todos" ? "2023-2024" : selectedYear}</span>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Vehículo Seleccionado</p>
              <span className="font-semibold">{selectedVehicle === "todos" ? "Todos los vehículos" : selectedVehicle}</span>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Fecha de Generación</p>
              <span className="font-semibold">{new Date().toLocaleDateString('es-AR')}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {reportTypes.map((report) => (
          <Card key={report.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{report.titulo}</CardTitle>
                  <CardDescription className="mt-2">{report.descripcion}</CardDescription>
                </div>
                <FileText className="w-5 h-5 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Frecuencia:</span>
                  <Badge variant="outline">{report.frecuencia}</Badge>
                </div>

                <Separator />

                <div>
                  <p className="text-sm text-muted-foreground mb-3">Descargar en:</p>
                  <div className="flex flex-wrap gap-2">
                    {report.formatos.map((formato) => (
                      <Button key={formato} variant="outline" size="sm" className="gap-2">
                        {formato === "PDF" && <FileText className="w-4 h-4" />}
                        {(formato === "Excel" || formato === "CSV") && <FileSpreadsheet className="w-4 h-4" />}
                        <Download className="w-3 h-3" />
                        {formato}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-muted/50">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Calendar className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground mb-1">Reportes Automáticos</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Configura la generación y envío automático de reportes mensuales por email
              </p>
              <Button variant="outline" size="sm">
                Configurar Automatización
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
