"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download } from 'lucide-react'
import { vehicleTypes } from "@/lib/fuel-data"

interface DashboardHeaderProps {
  selectedYear: "2023" | "2024" | "todos"
  setSelectedYear: (year: "2023" | "2024" | "todos") => void
  selectedVehicle: string
  setSelectedVehicle: (vehicle: string) => void
}

export function DashboardHeader({
  selectedYear,
  setSelectedYear,
  selectedVehicle,
  setSelectedVehicle,
}: DashboardHeaderProps) {
  return (
    <header className="border-b border-border bg-card">
      <div className="px-6 py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground text-balance">
              Dashboard de Consumo de Combustible
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Municipalidad de Monte Quemado
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Select value={selectedYear} onValueChange={(v) => setSelectedYear(v as any)}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Año" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2024">2024</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
              <SelectTrigger className="w-[220px]">
                <SelectValue placeholder="Tipo de Vehículo" />
              </SelectTrigger>
              <SelectContent>
                {vehicleTypes.map((vehicle) => (
                  <SelectItem key={vehicle.value} value={vehicle.value}>
                    {vehicle.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exportar</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
