"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, AlertCircle, Info, CheckCircle, X } from 'lucide-react'
import { cn } from "@/lib/utils"

const alerts = [
  {
    id: 1,
    tipo: "critico" as const,
    titulo: "Consumo Excesivo Detectado",
    descripcion: "Camión Recolector 01 superó el límite mensual en 280 litros (7% sobre límite)",
    vehiculo: "Camión 01",
    fecha: "15/01/2024 14:30",
    estado: "activa" as const,
  },
  {
    id: 2,
    tipo: "advertencia" as const,
    titulo: "Tendencia al Alza",
    descripcion: "Camioneta Municipal 01 muestra aumento del 12% en consumo vs mes anterior",
    vehiculo: "Camioneta 01",
    fecha: "14/01/2024 09:15",
    estado: "activa" as const,
  },
  {
    id: 3,
    tipo: "info" as const,
    titulo: "Carga Duplicada Detectada",
    descripcion: "Posible registro duplicado: Ambulancia 01 - 13/01/2024 - 38L",
    vehiculo: "Ambulancia 01",
    fecha: "13/01/2024 16:45",
    estado: "revisada" as const,
  },
  {
    id: 4,
    tipo: "advertencia" as const,
    titulo: "Carga Fuera de Horario",
    descripcion: "Carga realizada a las 23:45hs - Verificar autorización",
    vehiculo: "Camioneta 02",
    fecha: "12/01/2024 23:45",
    estado: "resuelta" as const,
  },
  {
    id: 5,
    tipo: "info" as const,
    titulo: "Mantenimiento Programado",
    descripcion: "Recordatorio: Service de 10.000km para Motoniveladora",
    vehiculo: "Motoniveladora",
    fecha: "10/01/2024 10:00",
    estado: "activa" as const,
  },
]

interface AlertsSectionProps {
  selectedYear: string
}

export function AlertsSection({ selectedYear }: AlertsSectionProps) {
  const getAlertIcon = (tipo: "critico" | "advertencia" | "info") => {
    switch (tipo) {
      case "critico":
        return <AlertTriangle className="w-5 h-5" />
      case "advertencia":
        return <AlertCircle className="w-5 h-5" />
      case "info":
        return <Info className="w-5 h-5" />
    }
  }

  const getAlertColor = (tipo: "critico" | "advertencia" | "info") => {
    switch (tipo) {
      case "critico":
        return "text-destructive"
      case "advertencia":
        return "text-amber-500"
      case "info":
        return "text-blue-500"
    }
  }

  const getStatusBadge = (estado: "activa" | "revisada" | "resuelta") => {
    switch (estado) {
      case "activa":
        return <Badge variant="destructive">Activa</Badge>
      case "revisada":
        return <Badge variant="secondary">Revisada</Badge>
      case "resuelta":
        return <Badge variant="outline" className="gap-1">
          <CheckCircle className="w-3 h-3" />
          Resuelta
        </Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Sistema de Alertas</h2>
        <p className="text-muted-foreground">
          Notificaciones y eventos importantes del sistema
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Alertas Críticas</p>
                <p className="text-3xl font-bold text-destructive mt-2">1</p>
              </div>
              <div className="p-3 bg-destructive/10 rounded-lg">
                <AlertTriangle className="w-6 h-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Advertencias</p>
                <p className="text-3xl font-bold text-amber-500 mt-2">2</p>
              </div>
              <div className="p-3 bg-amber-500/10 rounded-lg">
                <AlertCircle className="w-6 h-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Informativas</p>
                <p className="text-3xl font-bold text-blue-500 mt-2">2</p>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <Info className="w-6 h-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <Card key={alert.id} className={cn(
            alert.tipo === "critico" && alert.estado === "activa" && "border-destructive/50"
          )}>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-3 flex-1">
                  <div className={cn("mt-0.5", getAlertColor(alert.tipo))}>
                    {getAlertIcon(alert.tipo)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <CardTitle className="text-base">{alert.titulo}</CardTitle>
                      {getStatusBadge(alert.estado)}
                    </div>
                    <CardDescription className="text-sm mt-1">
                      {alert.descripcion}
                    </CardDescription>
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <span>Vehículo: <span className="font-medium text-foreground">{alert.vehiculo}</span></span>
                      <span>•</span>
                      <span>{alert.fecha}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  {alert.estado === "activa" && (
                    <>
                      <Button variant="outline" size="sm">
                        Revisar
                      </Button>
                      <Button variant="ghost" size="sm">
                        <X className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  )
}
