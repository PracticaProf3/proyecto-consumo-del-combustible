"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { OverviewSection } from "@/components/overview-section"
import { VehiclesSection } from "@/components/vehicles-section"
import { HistoricalSection } from "@/components/historical-section"
import { AlertsSection } from "@/components/alerts-section"
import { ReportsSection } from "@/components/reports-section"

export type SectionType = "resumen" | "vehiculos" | "historico" | "alertas" | "reportes"

export function DashboardShell() {
  const [activeSection, setActiveSection] = useState<SectionType>("resumen")
  const [selectedYear, setSelectedYear] = useState<"2023" | "2024" | "todos">("2024")
  const [selectedVehicle, setSelectedVehicle] = useState<string>("todos")

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <div className="flex-1 flex flex-col">
        <DashboardHeader 
          selectedYear={selectedYear}
          setSelectedYear={setSelectedYear}
          selectedVehicle={selectedVehicle}
          setSelectedVehicle={setSelectedVehicle}
        />
        
        <main className="flex-1 p-6 overflow-auto">
          {activeSection === "resumen" && (
            <OverviewSection selectedYear={selectedYear} selectedVehicle={selectedVehicle} />
          )}
          {activeSection === "vehiculos" && (
            <VehiclesSection selectedYear={selectedYear} />
          )}
          {activeSection === "historico" && (
            <HistoricalSection selectedYear={selectedYear} selectedVehicle={selectedVehicle} />
          )}
          {activeSection === "alertas" && (
            <AlertsSection selectedYear={selectedYear} />
          )}
          {activeSection === "reportes" && (
            <ReportsSection selectedYear={selectedYear} selectedVehicle={selectedVehicle} />
          )}
        </main>
      </div>
    </div>
  )
}
