import { DashboardShell } from "@/components/dashboard-shell"

export default function DashboardPage() {
  return <DashboardShell />
}
