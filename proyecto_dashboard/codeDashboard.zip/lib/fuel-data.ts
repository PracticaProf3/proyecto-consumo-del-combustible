export const fuelData = [
  {
    "Mes": 1,
    "Gasoil (L)": 4340,
    "Nafta (L)": 390,
    "Km Recorridos": 21700,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 3,
    "Retroexcavadoras": 1,
    "Motos": 4,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  },
  {
    "Mes": 2,
    "Gasoil (L)": 5970,
    "Nafta (L)": 280,
    "Km Recorridos": 29850,
    "Camiones Tanque": 5,
    "Compactadores": 2,
    "Camionetas": 4,
    "Tractores": 3,
    "Retroexcavadoras": 1,
    "Motos": 3,
    "Motos Niveladoras": 1,
    "Viajes Largos": 3
  },
  {
    "Mes": 3,
    "Gasoil (L)": 5890,
    "Nafta (L)": 240,
    "Km Recorridos": 29450,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 3,
    "Retroexcavadoras": 2,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  },
  {
    "Mes": 4,
    "Gasoil (L)": 7630,
    "Nafta (L)": 350,
    "Km Recorridos": 38150,
    "Camiones Tanque": 5,
    "Compactadores": 3,
    "Camionetas": 4,
    "Tractores": 4,
    "Retroexcavadoras": 2,
    "Motos": 3,
    "Motos Niveladoras": 2,
    "Viajes Largos": 4
  },
  {
    "Mes": 5,
    "Gasoil (L)": 8260,
    "Nafta (L)": 690,
    "Km Recorridos": 41300,
    "Camiones Tanque": 6,
    "Compactadores": 3,
    "Camionetas": 4,
    "Tractores": 4,
    "Retroexcavadoras": 2,
    "Motos": 4,
    "Motos Niveladoras": 2,
    "Viajes Largos": 4
  },
  {
    "Mes": 6,
    "Gasoil (L)": 4681,
    "Nafta (L)": 450,
    "Km Recorridos": 23405,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 2,
    "Retroexcavadoras": 1,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 1
  },
  {
    "Mes": 7,
    "Gasoil (L)": 5500,
    "Nafta (L)": 200,
    "Km Recorridos": 27500,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 2,
    "Retroexcavadoras": 2,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  },
  {
    "Mes": 8,
    "Gasoil (L)": 3640,
    "Nafta (L)": 120,
    "Km Recorridos": 18200,
    "Camiones Tanque": 3,
    "Compactadores": 2,
    "Camionetas": 2,
    "Tractores": 2,
    "Retroexcavadoras": 1,
    "Motos": 1,
    "Motos Niveladoras": 1,
    "Viajes Largos": 1
  },
  {
    "Mes": 9,
    "Gasoil (L)": 5740,
    "Nafta (L)": 320,
    "Km Recorridos": 28700,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 3,
    "Retroexcavadoras": 1,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  },
  {
    "Mes": 10,
    "Gasoil (L)": 3800,
    "Nafta (L)": 460,
    "Km Recorridos": 34000,
    "Camiones Tanque": 5,
    "Compactadores": 3,
    "Camionetas": 3,
    "Tractores": 3,
    "Retroexcavadoras": 2,
    "Motos": 3,
    "Motos Niveladoras": 2,
    "Viajes Largos": 3
  },
  {
    "Mes": 11,
    "Gasoil (L)": 4250,
    "Nafta (L)": 549,
    "Km Recorridos": 26250,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 3,
    "Retroexcavadoras": 1,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  },
  {
    "Mes": 12,
    "Gasoil (L)": 2542,
    "Nafta (L)": 368,
    "Km Recorridos": 22710,
    "Camiones Tanque": 4,
    "Compactadores": 2,
    "Camionetas": 3,
    "Tractores": 2,
    "Retroexcavadoras": 1,
    "Motos": 2,
    "Motos Niveladoras": 1,
    "Viajes Largos": 2
  }
]

export const vehicleTypes = [
  { value: "todos", label: "Todos los vehículos" },
  { value: "camiones-tanque", label: "Camiones Tanque" },
  { value: "compactadores", label: "Compactadores" },
  { value: "camionetas", label: "Camionetas" },
  { value: "tractores", label: "Tractores" },
  { value: "retroexcavadoras", label: "Retroexcavadoras" },
  { value: "motos", label: "Motos" },
  { value: "motos-niveladoras", label: "Motos Niveladoras" },
]

export const monthNames = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
]

// Funciones para calcular estadísticas
export function getTotalConsumption() {
  return fuelData.reduce((sum, month) => sum + month["Gasoil (L)"] + month["Nafta (L)"], 0)
}

export function getTotalGasoil() {
  return fuelData.reduce((sum, month) => sum + month["Gasoil (L)"], 0)
}

export function getTotalNafta() {
  return fuelData.reduce((sum, month) => sum + month["Nafta (L)"], 0)
}

export function getTotalKm() {
  return fuelData.reduce((sum, month) => sum + month["Km Recorridos"], 0)
}

export function getAverageEfficiency() {
  const totalFuel = getTotalConsumption()
  const totalKm = getTotalKm()
  return (totalKm / totalFuel).toFixed(2)
}

export function getMonthWithMaxConsumption() {
  const maxMonth = fuelData.reduce((max, month) => {
    const total = month["Gasoil (L)"] + month["Nafta (L)"]
    const maxTotal = max["Gasoil (L)"] + max["Nafta (L)"]
    return total > maxTotal ? month : max
  })
  return {
    month: monthNames[maxMonth.Mes - 1],
    consumption: maxMonth["Gasoil (L)"] + maxMonth["Nafta (L)"]
  }
}

export function getMonthWithMinConsumption() {
  const minMonth = fuelData.reduce((min, month) => {
    const total = month["Gasoil (L)"] + month["Nafta (L)"]
    const minTotal = min["Gasoil (L)"] + min["Nafta (L)"]
    return total < minTotal ? month : min
  })
  return {
    month: monthNames[minMonth.Mes - 1],
    consumption: minMonth["Gasoil (L)"] + minMonth["Nafta (L)"]
  }
}
